package com.spring.user.controller;

import com.spring.user.entities.ShoppingCartEntity;
import com.spring.user.services.ShoppingCartServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.sql.Timestamp;
import java.util.Date;


@Controller
public class ShoppingCartController {
    public ShoppingCartController() {
        System.out.println(getClass().getSimpleName() + " created.");
    }

    @Autowired
    private ShoppingCartServices shoppingCartServices;




    public ModelAndView getIndex() {
        ModelAndView modelAndView = new ModelAndView("index");
        modelAndView.addObject("shoppingCart", shoppingCartServices.getAllShoppingCarts());
        return modelAndView;
    }

    @GetMapping("/editShoppingCart/{id}")
    public ModelAndView editUser(@PathVariable Integer id) {
        ModelAndView modelAndView = new ModelAndView("shoppingCart");
        modelAndView.addObject("shoppingCart", shoppingCartServices.getShoppingCart(id));
        return modelAndView;
    }

    @GetMapping("/deleteShoppingCart/{id}")
    public ModelAndView deleteUser(@PathVariable Integer id) {
        ModelAndView modelAndView = new ModelAndView("redirect:/");
        shoppingCartServices.deleteShoppingCart(id);
        return modelAndView;
    }

    @GetMapping("/addShoppingCart")
    public ModelAndView addShoppingCart(){
        ModelAndView modelAndView = new ModelAndView("shoppingCart");
        modelAndView.addObject("shoppingCart", new ShoppingCartEntity());
        return modelAndView;
    }

    @PostMapping("/saveShoppingCart")
    public ModelAndView saveShoppingCart(@Valid @ModelAttribute("shoppingCart") ShoppingCartEntity shoppingCartEntity, BindingResult bindingResult){
        ModelAndView modelAndView = new ModelAndView("redirect:/");
        if(bindingResult.hasErrors()){
            modelAndView.addObject("shoppingCart", shoppingCartEntity);
            modelAndView.setViewName("shoppingCart");
            return modelAndView;
        }
        Timestamp timestamp= new Timestamp(new Date().getTime());
        if(null==shoppingCartEntity.getShoppingCartId()){
            shoppingCartEntity.setInsertTimestamp(timestamp);
        }
        shoppingCartEntity.setInsertTimestamp(timestamp);
        shoppingCartEntity.setUpdateTimestamp(timestamp);
        shoppingCartServices.saveShoppingCart(shoppingCartEntity);
        return modelAndView;
    }
}
