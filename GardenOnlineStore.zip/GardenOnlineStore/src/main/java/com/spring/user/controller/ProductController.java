package com.spring.user.controller;


import com.spring.user.entities.ProductEntity;
import com.spring.user.services.ProductServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.sql.Timestamp;
import java.util.Date;

public class ProductController {


    public ProductController() {
        System.out.println(getClass().getSimpleName() + " created.");
    }

    @Autowired
    private ProductServices productServices;

    public ModelAndView getIndex() {
        ModelAndView modelAndView = new ModelAndView("index");
        modelAndView.addObject("product", productServices.getAll());
        return modelAndView;
    }

    @GetMapping("/editProduct/{id}")
    public ModelAndView editProduct(@PathVariable Integer id) {
        ModelAndView modelAndView = new ModelAndView("product");
        modelAndView.addObject("product", productServices.getProduct(id));
        return modelAndView;
    }

    @GetMapping("/deleteProduct/{id}")
    public ModelAndView deleteProduct(@PathVariable Integer id) {
        ModelAndView modelAndView = new ModelAndView("redirect:/");
        productServices.deleteProduct(id);
        return modelAndView;
    }

    @GetMapping("/addProduct")
    public ModelAndView addProduct(){
        ModelAndView modelAndView = new ModelAndView("product");
        modelAndView.addObject("product", new ProductEntity());
        return modelAndView;
    }

    @PostMapping("/saveProduct")
    public ModelAndView saveGuest(@Valid @ModelAttribute("product") ProductEntity productEntity, BindingResult bindingResult){
        ModelAndView modelAndView = new ModelAndView("redirect:/");
        if(bindingResult.hasErrors()){
            modelAndView.addObject("product", productEntity);
            modelAndView.setViewName("product");
            return modelAndView;
        }
        Timestamp timestamp= new Timestamp(new Date().getTime());
        if(null==productEntity.getProductId()){
            productEntity.setInsertTimestamp(timestamp);
        }
        productEntity.setInsertTimestamp(timestamp);
        productEntity.setUpdateTimestamp(timestamp);
        productServices.saveProduct(productEntity);
        return modelAndView;
    }
}
