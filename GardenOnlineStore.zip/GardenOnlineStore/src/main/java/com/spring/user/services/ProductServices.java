package com.spring.user.services;

import com.spring.user.entities.ProductEntity;
import com.spring.user.repositories.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service

public class ProductServices {

    public ProductServices() {
        System.out.println(getClass().getSimpleName() + " created.");
    }

    @Autowired
    private ProductRepository productRepository;

    public List<ProductEntity> getAll() {
        return productRepository.findAll();

    }

    public ProductEntity getProduct(Integer id){
        return productRepository.getOne(id);
    }

    public void saveProduct (ProductEntity productEntity){
        productRepository.save(productEntity);
    }

    public void deleteProduct(Integer id){
        productRepository.deleteById(id);
    }
}
