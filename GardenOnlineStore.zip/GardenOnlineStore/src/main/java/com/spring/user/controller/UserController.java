package com.spring.user.controller;

import com.spring.user.entities.UserEntity;
import com.spring.user.services.UserServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.sql.Timestamp;
import java.util.Date;

//@RequestMapping("api/v1/user")
@Controller
public class UserController {
    public UserController() {
        System.out.println(getClass().getSimpleName() + " created.");
    }

    @Autowired
    private UserServices userServices;




    public ModelAndView getIndex() {
        ModelAndView modelAndView = new ModelAndView("index");
        modelAndView.addObject("users", userServices.getAllUsers());
        return modelAndView;
    }

    @GetMapping("/editUser/{id}")
    public ModelAndView editUser(@PathVariable Integer id) {
        ModelAndView modelAndView = new ModelAndView("user");
        modelAndView.addObject("user", userServices.getUser(id));
        return modelAndView;
    }

    @GetMapping("/deleteUser/{id}")
    public ModelAndView deleteUser(@PathVariable Integer id) {
        ModelAndView modelAndView = new ModelAndView("redirect:/");
        userServices.deleteUser(id);
        return modelAndView;
    }

    @GetMapping("/addUser")
    public ModelAndView addUser(){
        ModelAndView modelAndView = new ModelAndView("user");
        modelAndView.addObject("user", new UserEntity());
        return modelAndView;
    }

    @PostMapping("/saveUser")
    public ModelAndView saveUser(@Valid @ModelAttribute("user") UserEntity usersEntity, BindingResult bindingResult){
        ModelAndView modelAndView = new ModelAndView("redirect:/");
        if(bindingResult.hasErrors()){
            modelAndView.addObject("user", usersEntity);
            modelAndView.setViewName("user");
            return modelAndView;
        }
        Timestamp timestamp= new Timestamp(new Date().getTime());
        if(null==usersEntity.getUserId()){
            usersEntity.setInsertTimestamp(timestamp);
        }
        usersEntity.setInsertTimestamp(timestamp);
        usersEntity.setUpdateTimestamp(timestamp);
        userServices.saveUser(usersEntity);
        return modelAndView;
    }
}