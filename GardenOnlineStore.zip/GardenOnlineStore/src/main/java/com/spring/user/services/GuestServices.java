package com.spring.user.services;



import com.spring.user.entities.GuestEntity;
import com.spring.user.repositories.GuestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service

public class GuestServices {

    public GuestServices() {
        System.out.println(getClass().getSimpleName() + " created.");
    }

    @Autowired
    private GuestRepository guestRepository;

    public List<GuestEntity> getAll() {
        return guestRepository.findAll();

    }

    public GuestEntity getGuest(Integer id){
        return guestRepository.getOne(id);
    }

    public void saveGuest (GuestEntity guestEntity){
        guestRepository.save(guestEntity);
    }

    public void deleteGuest(Integer id){
        guestRepository.deleteById(id);
    }
}
