package com.spring.user.services;

import com.spring.user.entities.ShoppingCartEntity;
import com.spring.user.repositories.ShoppingCartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ShoppingCartServices {
    public ShoppingCartServices() {
        System.out.println(getClass().getSimpleName() + " created.");
    }

    @Autowired
    private ShoppingCartRepository shoppingCartRepository;

    public List<ShoppingCartEntity> getAllShoppingCarts() {
        return shoppingCartRepository.findAll();

    }

    public ShoppingCartEntity getShoppingCart(Integer id){
        return shoppingCartRepository.getOne(id);
    }

    public void saveShoppingCart (ShoppingCartEntity shoppingCartEntity){
        shoppingCartRepository.save(shoppingCartEntity);
    }

    public void deleteShoppingCart(Integer id){
        shoppingCartRepository.deleteById(id);
    }
}
