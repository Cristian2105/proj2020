package com.spring.user.controller;


import com.spring.user.entities.GuestEntity;
import com.spring.user.services.GuestServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.sql.Timestamp;
import java.util.Date;

public class GuestController {

    public GuestController() {
        System.out.println(getClass().getSimpleName() + " created.");
    }

    @Autowired
    private GuestServices guestServices;

    public ModelAndView getIndex() {
        ModelAndView modelAndView = new ModelAndView("index");
        modelAndView.addObject("guest", guestServices.getAll());
        return modelAndView;
    }

    @GetMapping("/editGuest/{id}")
    public ModelAndView editGuest(@PathVariable Integer id) {
        ModelAndView modelAndView = new ModelAndView("guest");
        modelAndView.addObject("guest", guestServices.getGuest(id));
        return modelAndView;
    }

    @GetMapping("/deleteGuest/{id}")
    public ModelAndView deleteGuest(@PathVariable Integer id) {
        ModelAndView modelAndView = new ModelAndView("redirect:/");
        guestServices.deleteGuest(id);
        return modelAndView;
    }

    @GetMapping("/addGuest")
    public ModelAndView addGuest(){
        ModelAndView modelAndView = new ModelAndView("guest");
        modelAndView.addObject("guest", new GuestEntity());
        return modelAndView;
    }

    @PostMapping("/saveGuest")
    public ModelAndView saveGuest(@Valid @ModelAttribute("guest") GuestEntity guestEntity, BindingResult bindingResult){
        ModelAndView modelAndView = new ModelAndView("redirect:/");
        if(bindingResult.hasErrors()){
            modelAndView.addObject("guest", guestEntity);
            modelAndView.setViewName("guest");
            return modelAndView;
        }
        Timestamp timestamp= new Timestamp(new Date().getTime());
        if(null==guestEntity.getGuestId()){
            guestEntity.setInsertTimestamp(timestamp);
        }
        guestEntity.setInsertTimestamp(timestamp);
        guestEntity.setUpdateTimestamp(timestamp);
        guestServices.saveGuest(guestEntity);
        return modelAndView;
    }
}
