package com.spring.user.entities;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name="ShoppingCart")


public class ShoppingCartEntity {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)

    private Integer shoppingCartId;
    private Integer productId;
    private Integer userId;
    private Integer totalPrice;
    private Timestamp insertTimestamp;
    private Timestamp updateTimestamp;
    private Boolean deleted;

    public ShoppingCartEntity() { };

    public Integer getShoppingCartId() {
        return shoppingCartId;
    }

    public void setShoppingCartId(Integer shoppingCartId) {
        this.shoppingCartId = shoppingCartId;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(Integer totalPrice) {
        this.totalPrice = totalPrice;
    }

    public Timestamp getInsertTimestamp() {
        return insertTimestamp;
    }

    public void setInsertTimestamp(Timestamp insertTimestamp) {
        this.insertTimestamp = insertTimestamp;
    }

    public Timestamp getUpdateTimestamp() {
        return updateTimestamp;
    }

    public void setUpdateTimestamp(Timestamp updateTimestamp) {
        this.updateTimestamp = updateTimestamp;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }
}
