package com.spring.user.controller;


import com.spring.user.entities.InvoiceEntity;
import com.spring.user.services.InvoiceServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import javax.validation.Valid;
import java.sql.Timestamp;
import java.util.Date;

//@RequestMapping("api/v1/user")
@Controller
public class InvoiceController {
    public InvoiceController() {
        System.out.println(getClass().getSimpleName() + " created.");
    }

    @Autowired
    private InvoiceServices invoiceServices;


    public ModelAndView getIndex() {
        ModelAndView modelAndView = new ModelAndView("index");
        modelAndView.addObject("invoice", invoiceServices.getAllInvoices());
        return modelAndView;
    }

    @GetMapping("/editInvoice/{id}")
    public ModelAndView editInvoice(@PathVariable Integer id) {
        ModelAndView modelAndView = new ModelAndView("invoice");
        modelAndView.addObject("invoice", invoiceServices.getInvoice(id));
        return modelAndView;
    }

    @GetMapping("/deleteInvoice/{id}")
    public ModelAndView deleteInvoice(@PathVariable Integer id) {
        ModelAndView modelAndView = new ModelAndView("redirect:/");
        invoiceServices.deleteInvoice(id);
        return modelAndView;
    }

    @GetMapping("/addInvoice")
    public ModelAndView addUser(){
        ModelAndView modelAndView = new ModelAndView("invoice");
        modelAndView.addObject("invoice", new InvoiceEntity());
        return modelAndView;
    }

    @PostMapping("/saveInvoice")
    public ModelAndView saveInvoice(@Valid @ModelAttribute("invoice") InvoiceEntity invoiceEntity, BindingResult bindingResult){
        ModelAndView modelAndView = new ModelAndView("redirect:/");
        if(bindingResult.hasErrors()){
            modelAndView.addObject("invoice", invoiceEntity);
            modelAndView.setViewName("invoice");
            return modelAndView;
        }
        Timestamp timestamp= new Timestamp(new Date().getTime());
        if(null==invoiceEntity.getInvoiceId()){
            invoiceEntity.setInsertTimestamp(timestamp);
        }
        invoiceEntity.setInsertTimestamp(timestamp);
        invoiceEntity.setUpdateTimestamp(timestamp);
        invoiceServices.saveInvoice(invoiceEntity);
        return modelAndView;
    }
}
