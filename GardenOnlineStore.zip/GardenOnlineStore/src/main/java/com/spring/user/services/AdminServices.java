package com.spring.user.services;

import com.spring.user.entities.AdminEntity;
import com.spring.user.repositories.AdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service

public class AdminServices {

    public AdminServices() {
        System.out.println(getClass().getSimpleName() + " created.");
    }

    @Autowired
    private AdminRepository adminRepository;

    public List<AdminEntity> getAll() {
        return adminRepository.findAll();

    }

    public AdminEntity getAdmin(Integer id){
        return adminRepository.getOne(id);
    }

    public void saveAdmin (AdminEntity adminEntity){
        adminRepository.save(adminEntity);
    }

    public void deleteAdmin(Integer id){
        adminRepository.deleteById(id);
    }
}


