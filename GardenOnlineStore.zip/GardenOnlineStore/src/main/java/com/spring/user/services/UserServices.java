package com.spring.user.services;

import com.spring.user.entities.UserEntity;
import com.spring.user.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServices {
    public UserServices() {
        System.out.println(getClass().getSimpleName() + " created.");
    }

    @Autowired
    private UserRepository usersRepository;

    public List<UserEntity> getAllUsers() {
        return usersRepository.findAll();        //de afisat doar cei cu 0 la deleted , doar cei activi cum ar veni
//        usersRepository.findAllByDeletedFalse()
    }

    public UserEntity getUser(Integer id){
        return usersRepository.getOne(id);
    }

    public void saveUser (UserEntity usersEntity){
        usersRepository.save(usersEntity);
    }

    public void deleteUser(Integer id){
        usersRepository.deleteById(id);            //de pus un camp   DELETED in db   1 sters  0 default
    }
}
