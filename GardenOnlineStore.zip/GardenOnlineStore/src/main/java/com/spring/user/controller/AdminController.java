package com.spring.user.controller;

import com.spring.user.entities.AdminEntity;
import com.spring.user.services.AdminServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.sql.Timestamp;
import java.util.Date;

public class AdminController {

    public AdminController() {
        System.out.println(getClass().getSimpleName() + " created.");
    }

    @Autowired
    private AdminServices adminServices;


    public ModelAndView getIndex() {
        ModelAndView modelAndView = new ModelAndView("index");
        modelAndView.addObject("admin", adminServices.getAll());
        return modelAndView;
    }

    @GetMapping("/editAdmin/{id}")
    public ModelAndView editUser(@PathVariable Integer id) {
        ModelAndView modelAndView = new ModelAndView("admin");
        modelAndView.addObject("admin", adminServices.getAdmin(id));
        return modelAndView;
    }

    @GetMapping("/deleteAdmin/{id}")
    public ModelAndView deleteUser(@PathVariable Integer id) {
        ModelAndView modelAndView = new ModelAndView("redirect:/");
        adminServices.deleteAdmin(id);
        return modelAndView;
    }

    @GetMapping("/addAdmin")
    public ModelAndView addUser(){
        ModelAndView modelAndView = new ModelAndView("admin");
        modelAndView.addObject("admin", new AdminEntity());
        return modelAndView;
    }

    @PostMapping("/saveAdmin")
    public ModelAndView saveUser(@Valid @ModelAttribute("admin") AdminEntity adminEntity, BindingResult bindingResult){
        ModelAndView modelAndView = new ModelAndView("redirect:/");
        if(bindingResult.hasErrors()){
            modelAndView.addObject("admin", adminEntity);
            modelAndView.setViewName("admin");
            return modelAndView;
        }
        Timestamp timestamp= new Timestamp(new Date().getTime());
        if(null==adminEntity.getAdminId()){
            adminEntity.setInsertTimestamp(timestamp);
        }
        adminEntity.setInsertTimestamp(timestamp);
        adminEntity.setUpdateTimestamp(timestamp);
        adminServices.saveAdmin(adminEntity);
        return modelAndView;
    }
}
