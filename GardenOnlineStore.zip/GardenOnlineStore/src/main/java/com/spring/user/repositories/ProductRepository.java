package com.spring.user.repositories;

import com.spring.user.entities.ProductEntity;
import com.spring.user.entities.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductRepository extends JpaRepository<ProductEntity, Integer> {

    List<ProductEntity> findAll();
}
