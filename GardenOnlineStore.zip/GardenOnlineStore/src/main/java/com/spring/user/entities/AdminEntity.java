package com.spring.user.entities;

import javax.persistence.*;
import javax.validation.constraints.Size;
import java.sql.Timestamp;

@Entity
@Table(name="admin")

public class AdminEntity {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Integer adminId;

    @Size(min=2, max= 10, message = "Nume incorect ")
    private String firstName;
    @Size(min=2, max= 10, message = "Nume incorect ")
    private String lastName;

    private Boolean active;
    private Boolean deleted;
    private Timestamp insertTimestamp;
    private Timestamp updateTimestamp;

    public AdminEntity() {
    }

    public Integer getAdminId(){return adminId;}

    public void setAdminId(Integer adminId) {
        this.adminId = adminId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public Timestamp getInsertTimestamp() {
        return insertTimestamp;
    }

    public void setInsertTimestamp(Timestamp insertTimestamp) {
        this.insertTimestamp = insertTimestamp;
    }

    public Timestamp getUpdateTimestamp() {
        return updateTimestamp;
    }

    public void setUpdateTimestamp(Timestamp updateTimestamp) {
        this.updateTimestamp = updateTimestamp;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }
}
