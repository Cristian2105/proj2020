package com.spring.user.repositories;

import com.spring.user.entities.CommandEntity;
import com.spring.user.entities.GuestEntity;
import com.spring.user.entities.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface GuestRepository extends JpaRepository<GuestEntity, Integer> {

    List<GuestEntity> findAll();
}
