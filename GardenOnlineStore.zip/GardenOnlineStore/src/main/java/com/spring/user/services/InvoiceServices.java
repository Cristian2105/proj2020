package com.spring.user.services;

import com.spring.user.entities.InvoiceEntity;
import com.spring.user.entities.ShoppingCartEntity;
import com.spring.user.repositories.InvoiceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InvoiceServices {
    public InvoiceServices() {
        System.out.println(getClass().getSimpleName() + " created.");
    }

    @Autowired
    private InvoiceRepository invoiceRepository;

    public List<InvoiceEntity> getAllInvoices() {
        return invoiceRepository.findAll();

    }

    public InvoiceEntity getInvoice(Integer id){
        return invoiceRepository.getOne(id);
    }

    public void saveInvoice (InvoiceEntity invoiceEntity){
        invoiceRepository.save(invoiceEntity);
    }

    public void deleteInvoice(Integer id){
        invoiceRepository.deleteById(id);
    }
}
