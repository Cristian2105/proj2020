package com.spring.user.repositories;

import com.spring.user.entities.AdminEntity;
import com.spring.user.entities.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AdminRepository extends JpaRepository<AdminEntity, Integer> {

    List<AdminEntity> findAll();

}
