package com.spring.user.services;

import com.spring.user.entities.AdminEntity;
import com.spring.user.entities.CommandEntity;
import com.spring.user.repositories.CommandRepository;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class CommandServices {


    public CommandServices() {
        System.out.println(getClass().getSimpleName() + " created.");
    }

    @Autowired
    private CommandRepository commandRepository;

    public List<CommandEntity> getAll() {
        return commandRepository.findAll();

    }

    public CommandEntity getCommand(Integer id){
        return commandRepository.getOne(id);
    }

    public void saveCommand (CommandEntity commandEntity){
        commandRepository.save(commandEntity);
    }

    public void deleteCommand(Integer id){
        commandRepository.deleteById(id);
    }
}
