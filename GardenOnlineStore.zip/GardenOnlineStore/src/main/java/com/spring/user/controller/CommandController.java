package com.spring.user.controller;

import com.spring.user.entities.CommandEntity;
import com.spring.user.services.CommandServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.sql.Timestamp;
import java.util.Date;

public class CommandController {

    public CommandController() {
            System.out.println(getClass().getSimpleName() + " created.");
    }

    @Autowired
    private CommandServices commandServices;

    public ModelAndView getIndex() {
        ModelAndView modelAndView = new ModelAndView("index");
        modelAndView.addObject("command", commandServices.getAll());
        return modelAndView;
    }

    @GetMapping("/editCommand/{id}")
    public ModelAndView editCommand(@PathVariable Integer id) {
        ModelAndView modelAndView = new ModelAndView("command");
        modelAndView.addObject("command", commandServices.getCommand(id));
        return modelAndView;
    }

    @GetMapping("/deleteCommand/{id}")
    public ModelAndView deleteCommand(@PathVariable Integer id) {
        ModelAndView modelAndView = new ModelAndView("redirect:/");
        commandServices.deleteCommand(id);
        return modelAndView;
    }

    @GetMapping("/addCommand")
    public ModelAndView addCommand(){
        ModelAndView modelAndView = new ModelAndView("command");
        modelAndView.addObject("command", new CommandEntity());
        return modelAndView;
    }

    @PostMapping("/saveCommand")
    public ModelAndView saveCommand(@Valid @ModelAttribute("command") CommandEntity commandEntity, BindingResult bindingResult){
        ModelAndView modelAndView = new ModelAndView("redirect:/");
        if(bindingResult.hasErrors()){
            modelAndView.addObject("command", commandEntity);
            modelAndView.setViewName("command");
            return modelAndView;
        }
        Timestamp timestamp= new Timestamp(new Date().getTime());
        if(null==commandEntity.getCommandId()){
            commandEntity.setInsertTimestamp(timestamp);
        }
        commandEntity.setInsertTimestamp(timestamp);
        commandEntity.setUpdateTimestamp(timestamp);
        commandServices.saveCommand(commandEntity);
        return modelAndView;
    }
}
